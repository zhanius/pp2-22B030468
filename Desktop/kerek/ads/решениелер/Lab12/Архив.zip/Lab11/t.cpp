#include <iostream>

using namespace std;

int main() {
    int a, b; cin >> a >> b;
    swap(a, b);
    cout << a << b;
}